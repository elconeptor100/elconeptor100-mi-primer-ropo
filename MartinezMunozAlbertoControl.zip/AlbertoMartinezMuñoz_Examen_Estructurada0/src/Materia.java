
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alberto.martinez
 */
public class Materia {
  private String nombre;
  private double precio;
  private ArrayList<Alumno> alumnos;
  private ArrayList<Integer> notas;
  private int contador = 0;

  public Materia(String nombre, double precio) {
    this.nombre = nombre;
    this.precio = precio;
    this.alumnos = new ArrayList<>();
    this.notas = new ArrayList<>();
  }
  
  public void addAlumno(Alumno a) {
    alumnos.add(a);
    notas.add(0);
    contador++;
  }
  
  public void calificar(Alumno a, int nota) {
    int id = a.getId();
    notas.set(id, nota);
  }
  
  public boolean estaAlumno(int id){
      try{
          alumnos.get(id);
          return true;
          
      }catch (Exception e){
          return false;
      }
  }
  
  public double getImporte(){
      return precio;
  }
      
      
//      try{
//          alumnos.get(id);
//          return true;
//          
//      }catch (Exception e){
//          return false;
//      }
        

  
}
