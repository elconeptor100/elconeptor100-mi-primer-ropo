/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package albertomartinezmuñoz_examen_estructurada0;

import java.util.Scanner;

/**
 *
 * @author alberto.martinez
 */
public class Ejercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado= new Scanner (System.in);
        
        double n=0;
        double contpositivo=0;
        double contnegativo=0;
        double sumpositivo=0;
        double sumnegativo=0;
        double medianegativo=0;
        double mediapositivo=0;
        
        System.out.println("===== POSI Y NEGA ======");
        for (int i=1; i<=5; i++){
            System.out.print("Dime el numero "+i+" : ");
            n= Double.parseDouble(teclado.nextLine());
            
            if (n>0){
                contpositivo++;
                sumpositivo=sumpositivo+n;
            }
            
            else if (n<0){
                contnegativo++;
                sumnegativo=sumnegativo+n;
            }
              
        }
        
        if (contpositivo==0){
            System.out.printf("Hay %.0f numeros positivos. La media de estos es 0\n",contpositivo);
            
        }
        
        else if (contpositivo>=1){
            mediapositivo=sumpositivo/contpositivo;
            System.out.printf("Hay %.0f numeros positivos. La media de estos es %.2f\n",contpositivo,mediapositivo);
            
        }
        
        
        if (contnegativo==0){
            System.out.printf("Hay %.0f numeros negativos. La media de estos es 0\n",contnegativo);
            
        }
        
        else if (contnegativo>=1){
            medianegativo=sumnegativo/contnegativo;
            System.out.printf("Hay %.0f numeros negativos. La media de estos es %.2f\n",contnegativo,medianegativo);
            
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
