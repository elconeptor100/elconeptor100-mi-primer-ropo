/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package albertomartinezmuñoz_examen_estructurada0;

import java.util.Scanner;

/**
 *
 * @author alberto.martinez
 */
public class Ejercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado= new Scanner (System.in);
        
        double base;
        double exponente;
        boolean cero=false;
        boolean positivo=false;
        boolean negativo=false;        
        double resultadoneg=0; 
        double resultado=0;
        
        System.out.print("Introduce la base: ");
        base = Double.parseDouble(teclado.nextLine());
        System.out.print("Introduce el exponente: ");
        exponente= Double.parseDouble(teclado.nextLine());
        resultado=base;
        
        
        if(exponente==0){
            cero=true;
            
        }
        
        else if (exponente<0){
            negativo=true;
            for (int i=0; exponente<0; exponente++){ 
            resultado = base*resultado;
 
            }
        
        }
        
        else {
            positivo=true;
            for (int i=1; i<exponente; i++){
            resultado = base*resultado;
            
 
            }
                    
        }
        
        
        if (cero==true){
            System.out.printf("%.0f elevado a 0 es 1\n",base);
        }
        
        if (negativo==true){
            resultado=1/resultado;
            System.out.printf("%.0f elevado a %.0f es %.f\n",base,exponente,resultado);
        }    
        
                
        
        if (positivo==true){
            System.out.printf("%.0f elevado a %.0f es %.0f\n",base,exponente,resultado);
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
