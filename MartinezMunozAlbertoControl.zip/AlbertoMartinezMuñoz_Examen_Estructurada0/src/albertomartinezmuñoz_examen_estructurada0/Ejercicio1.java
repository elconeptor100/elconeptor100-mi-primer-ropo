/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package albertomartinezmuñoz_examen_estructurada0;

import java.util.Scanner;

/**
 *
 * @author alberto.martinez
 */
public class Ejercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado = new Scanner (System.in);
        String frase="";
        char caracter;
        int esp=0;
        int palabras=0;
        
        do{
            System.out.println("Introduce una frase");
            frase=teclado.nextLine();
            palabras=0;
            esp=0;
            
            for (int i=0;i<frase.length();i++){
                caracter=frase.charAt(i);
                
                if (caracter==' '){
                    esp++;
                }
            }    
            
        palabras = esp+1;
        System.out.println("Se han introducido " +palabras+ " palabras");    
            
        }while(!frase.equals(""));
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
