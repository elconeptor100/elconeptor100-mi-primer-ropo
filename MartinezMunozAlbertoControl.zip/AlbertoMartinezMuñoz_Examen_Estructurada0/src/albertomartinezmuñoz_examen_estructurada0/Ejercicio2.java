/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package albertomartinezmuñoz_examen_estructurada0;

import java.util.Scanner;

/**
 *
 * @author alberto.martinez
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner teclado = new Scanner (System.in);
        
        int opcion=-1;
        double millas=0;
        double kilometros=0;
        double valormilla=1.6093;
        
        
        
        do{
            System.out.println("Conversor de medidas");
            System.out.println("=====================");
            System.out.println("1.Millas a kilometros");
            System.out.println("2.Kilometros a millas");
            System.out.println("3.Salir");
            opcion=Integer.parseInt(teclado.nextLine());
            kilometros=0;
            millas=0;
            
            switch (opcion){
                case 1:
                    System.out.println("Cuantas millas?");
                    millas = Double.parseDouble(teclado.nextLine());
                    kilometros=millas*valormilla;
                    System.out.printf("%.2f millas son %.2f kilometros \n\n\n2"
                            + "",millas,kilometros);
                    break;
                
                case 2:
                    System.out.println("Cuantos kilometros?");
                    kilometros=Double.parseDouble(teclado.nextLine());
                    millas=kilometros/valormilla;
                    System.out.println(+millas);
                    System.out.printf("%.2f kilometros son %.2f millas \n\n\n",kilometros,millas);
                    break;
                    
                case 3:
                    opcion=0;
                    System.out.println("Ha salido del programa");
                    break;
                
                default:
                    System.out.println("Opción erronea");
            }
                   
        }while (opcion!=0);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
